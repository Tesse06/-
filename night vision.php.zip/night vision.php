<?php

/**
 * @name effecter
 * @main rapet\effecter
 * @author rapet
 * @version 0.0.1
 * @api 3.0.0
 */

namespace rapet;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket; 
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;

class effecter extends PluginBase implements Listener
{
    public function onEnable()
    {
    $a = new PluginCommand("야투", $this);
    $a->setPermission("Op");
    $a->setUsage("/cmd");
    $a->setDescription("command");
    $this->getServer()->getCommandMap()->register($this->getDescription()->getName(), $a);

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
}
  public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{
      $cmd = $command->getName();
    if ($cmd === "야투") {
        if($sender->isOp()){
$this->opui($sender);
} else {
    $this->Ui($sender);
}
}
return true;
}
public function opui(Player $player) {
      $encode = json_encode([
      "type" => "form",
      "title" => "§6§l¡!¡!¡ §r§7아갼투시 §6§l¡!¡!¡§r",
      "content" =>
      "",
      "buttons" => [
      [
      "text" => "§6§l¡!¡!¡ §r§7야간투시 받기 §6§l¡!¡!¡§r",
      ],
      [
      "text" => "§6§l¡!¡!¡ §r§7야간투시 제거 §6§l¡!¡!¡§r",
      ],
      [
      "text" => "§6§l¡!¡!¡ §r§7야간투시 지급하기 §6§l¡!¡!¡§r",
      ],
      [
      "text" => "§6§l¡!¡!¡ §r§7야간투시 제거하기 §6§l¡!¡!¡§r",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 1876;
      $pack->formData = $encode;
      $player->dataPacket($pack);
}
public function Ui(Player $player) {
      $encode = json_encode([
      "type" => "form",
      "title" => "§6§l¡!¡!¡ §r§7야간투시 §6§l¡!¡!¡§r",
      "content" =>
      "",
      "buttons" => [
      [
      "text" => "§6§l¡!¡!¡ §r§7야간투시 받기 §6§l¡!¡!¡§r",
      ],
      [
      "text" => "§6§l¡!¡!¡ §r§7야간투시 제거 §6§l¡!¡!¡§r",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 1876;
      $pack->formData = $encode;
      $player->dataPacket($pack);
}
public function Ccui(Player $player){
		$encode = json_encode([
			"type" => "custom_form",
			"title" => "",
			"content" => [
				[
				"type" => "input",
				"text" => "§b§l•§r §7효과를 제거할 §e§l온라인 플레이어§r§7의 §b§l닉§r§7을 적어주세요§r"
				]
				]
					]);
		$pack = new ModalFormRequestPacket();
		$pack->formId = 1267;
		$pack->formData = $encode;
		$player->dataPacket($pack);
	}
public function Cui(Player $player){
		$encode = json_encode([
			"type" => "custom_form",
			"title" => "",
			"content" => [
				[
				"type" => "input",
				"text" => "§b§l•§r §7지급할 §e§l온라인 플레이어§r§7의 §b§l닉§r§7을 적어주세요§r"
				],
				[
				"type" => "input",
				"text" => "§b§l•§r §7입자없애기가 없앤다면이라면 §0§ltrue §r§7생기는거라면 §0§lfalse§r§7를 적으세요§r"
				],
				[
				"type" => "input",
				"text" => "§b§l•§r §7지속할 §d§l시간초§r§7를 적으세요§r"
				]
				]
					]);
		$pack = new ModalFormRequestPacket();
		$pack->formId = 1266;
		$pack->formData = $encode;
		$player->dataPacket($pack);
	}
     public function hell(DataPacketReceiveEvent $event){
		$pack = $event->getPacket();
		$player = $event->getPlayer();
		$nn = $player->getName();
     if($pack instanceof ModalFormResponsePacket and $pack->formId == 1876){ 
			$val = json_decode($pack->formData, true);
			if(is_null($val)) return true;
			if($val == 0){
$player->addEffect ( new EffectInstance ( Effect::getEffect ( 16 ), 20 * 1060, 255, true ) );
       }
       if($val == 1){
           $player->removeEffect(16);
       }
			    
		if($val == 2){
$this->Cui($player);
       }
       if($val == 3){
           $this->Ccui($player);
       }
			  }      
			 
		   if($pack instanceof ModalFormResponsePacket and $pack->formId == 1266){

			$val = json_decode($pack->formData, true);

			if(is_null($val)) return true;
			
$newplayer = $this->getServer()->getPlayer($val[0]);

		   $newplayer->addEffect ( new EffectInstance ( Effect::getEffect ( 16 ), 20 * $val[2], 255, $val[1] ) );
            }
            if($pack instanceof ModalFormResponsePacket and $pack->formId == 1267){

			$val = json_decode($pack->formData, true);

			if(is_null($val)) return true;
			
$newplayer = $this->getServer()->getPlayer($val[0]);

		   $newplayer->removeEffect(16);
            }
			      }
}